import java.awt.*;

public class Function_Font {

    GUI gui;
    Font bold,italik;
    String selectedSekil;

    public Function_Font(GUI gui){
        this.gui=gui;
    }

    public void setSekil(String sekil){
        selectedSekil = sekil;

        switch (selectedSekil){
            case "italik":
                gui.textArea.setFont(italik);
                break;
            case "bold":
                gui.textArea.setFont(bold);
                break;


        }
    }

}
