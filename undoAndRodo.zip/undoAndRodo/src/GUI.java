import javax.swing.*;
import javax.swing.event.UndoableEditEvent;
import javax.swing.undo.UndoManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI implements ActionListener {

    JFrame arayuzu;
    JTextArea textArea;
    JMenuBar menuBar;
    JMenu menuEdit,menuFormat,menuSekil;
    JMenuItem iundo,irodo,iFontArial,iFontCSMS, iFontTNR,iFontSize8,iFontSize12,iFontSize16,iFontSize20,iFontSize24,iItalik,iBold;
    JMenu menuFont,menuSize;


    Function_Format format = new Function_Format(this);
    FunctionEdit edit = new FunctionEdit(this);
    Function_Font font = new Function_Font(this);
    UndoManager um = new UndoManager();


    public static void main(String[] args) {

        new GUI();
    }
    public GUI(){
        createArayuzu();
        createTextArea();
        createMenuBar();
        createEditMenu();
        createFormatMenu();
        createMenuSekil();
        format.selectedFont = "Arial";
        format.createFont(16);

        arayuzu.setVisible(true);
    }

    public void createArayuzu() {
        arayuzu = new JFrame("Notepad");
        arayuzu.setSize(800,600);
        arayuzu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void createTextArea(){
        textArea = new JTextArea();
        textArea.getDocument().addUndoableEditListener(
                new UndoManager(){
                    public void undoableEditHappened(UndoableEditEvent e){
                        um.addEdit(e.getEdit());
                    }
                }
        );


        arayuzu.add(textArea);
    }
    public void createMenuBar(){
        menuBar = new JMenuBar();
        arayuzu.setJMenuBar(menuBar);

        menuEdit = new JMenu("Undo&Rodo");
        menuBar.add(menuEdit);

        menuFormat = new JMenu("Font");
        menuBar.add(menuFormat);

        menuSekil = new JMenu("fontSekli");
        menuBar.add(menuSekil);
    }
    public void createEditMenu(){
        iundo = new JMenuItem("Undo");
        iundo.addActionListener(this);
        iundo.setActionCommand("Undo");
        menuEdit.add(iundo);

        irodo = new JMenuItem("Rodo");
        irodo.addActionListener(this);
        irodo.setActionCommand("Redo");
        menuEdit.add(irodo);
    }
    public void createFormatMenu(){
        menuFont = new JMenu("Font");
        menuFormat.add(menuFont);

        iFontArial =new JMenuItem("Arial");
        iFontArial.addActionListener(this);
        iFontArial.setActionCommand("Arial");
        menuFont.add(iFontArial);

        iFontCSMS =new JMenuItem("Comic Sans MS");
        iFontCSMS.addActionListener( this);
        iFontCSMS.setActionCommand("Comic Sans MS");
        menuFont.add(iFontCSMS);

        iFontTNR =new JMenuItem("Times New Roman");
        iFontTNR.addActionListener( this);
        iFontTNR.setActionCommand("Times New Roman");
        menuFont.add(iFontTNR);

        menuSize = new JMenu("FontSize");
        menuFormat.add(menuSize);

        iFontSize8 = new JMenuItem("8");
        iFontSize8.addActionListener( this);
        iFontSize8.setActionCommand("size8");
        menuSize.add(iFontSize8);

        iFontSize12 = new JMenuItem("12");
        iFontSize12.addActionListener( this);
        iFontSize12.setActionCommand("size12");
        menuSize.add(iFontSize12);

        iFontSize16 = new JMenuItem("16");
        iFontSize16.addActionListener( this);
        iFontSize16.setActionCommand("size16");
        menuSize.add(iFontSize16);

        iFontSize20 = new JMenuItem("20");
        iFontSize20.addActionListener( this);
        iFontSize20.setActionCommand("size20");
        menuSize.add(iFontSize20);

        iFontSize24 = new JMenuItem("24");
        iFontSize24.addActionListener( this);
        iFontSize24.setActionCommand("size24");
        menuSize.add(iFontSize24);
    }
    public void createMenuSekil(){
        iItalik = new JMenuItem("italik");
        iFontSize8.addActionListener( this);
        iFontSize8.setActionCommand("italik");
        menuSekil.add(iItalik);

        iBold = new JMenuItem("bold");
        iFontSize8.addActionListener( this);
        iFontSize8.setActionCommand("bold");
        menuSekil.add(iBold);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        switch (command){
            case  "Undo" : edit.undo();break;
            case  "Redo" : edit.redo();break;
            case "italik" : font.setSekil(command);break;
            case "bold" : font.setSekil(command);break;
            case "Arial":format.setFont(command);break;
            case "Comic Sans MS":format.setFont(command);break;
            case "Times New Roman":format.setFont(command);break;
            case "size8":format.createFont(8);break;
            case "size12":format.createFont(12);break;
            case "size16":format.createFont(16);break;
            case "size20":format.createFont(20);break;
            case "size24":format.createFont(24);break;


        }
    }
}
